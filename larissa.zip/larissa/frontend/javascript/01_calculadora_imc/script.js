// Declaração das variáveis
const resultado = document.querySelector('#resultado')
const altura = document.querySelector('#altura')
const peso = document.querySelector('#peso')

// Função para calcular o IMC
const calcIMC = () => {
    if (altura.value !== '' && peso.value !== '') {

        // Cálculo do IMC
        const imc = (peso.value / (altura.value * altura.value)).toFixed(2) 

        let classificacao = ''

        // Verificar os níveis de IMC
        if (imc < 18.5) {
            classificacao = 'Abaixo do peso'
        } else if (imc < 25) {
            classificacao = 'Peso normal'
        } else if (imc < 30) {
            classificacao = 'Acima do peso'
        } else if (imc < 35) {
            classificacao = 'Obesidade Grau I'
        } else if (imc < 41) {
            classificacao = 'Obesidade Grau II'
        } else {
            classificacao = 'Obesidade Grau III'
        }
        // Exibir o resultado na tela
        resultado.innerHTML = `IMC: ${imc} (${classificacao})`

    } else {
        // Alerta para cmampos vazios
        resultado.innerHTML = 'Preencha os campos!'
    }
}
