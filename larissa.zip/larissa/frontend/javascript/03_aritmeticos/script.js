// Variáveis
// Em JS podemos usar let, var ou const

let a = 25
let b = 5

soma = a + b

sub = a - b

mult = a * b

div = a / b

resto = a % b // resto da divisão

console.log("Soma: " + soma + ".")
console.log("Subtração: " + sub + ".")
console.log("Multiplicação: " + mult + ".")
console.log("Divisão: " + div + ".")
console.log("Resto: " + resto + ".")
