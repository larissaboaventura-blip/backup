let idade = 18
let possuiCNH = true

console.log(idade >= 18 && possuiCNH)

// Verifica se está habilitado ou não habilitado
if (idade >= 18 && possuiCNH) {
    console.log("Habilitado")
} else {
    console.log("Não habilitado")
}


