console.log("Bem-vindo ao JavaScript!")
