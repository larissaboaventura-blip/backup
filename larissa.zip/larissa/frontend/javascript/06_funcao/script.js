// Função para exibir a mensagem ao clicar no botão
function saudacao() {
    alert("Boa tarde! 😁")
}

// Chamada da função para que a mensagem seja exibida na tela
// saudacao()