const JsxExemplo = () => {
    // declaração de variaveis
    const userName = 'Hilarry'

    // Objeto usuario
    const user = {
        name: 'Matheus',
        lastName: 'Lara'
    }

    // Funções
    function saudacao(name){
        return `Olá, ${name}!`    }

    // Variáveis para usuario 
    const userIslogged = false
    const userRole = "admin";

    return(
        <div>
            <h3>Diversos exemplos.</h3>

            {/* {Listar dados do usuario} */}
            <p>Olá, {userName}</p>
            <br />
            <p>usuário: {user.name} {user.lastName}</p>
            <br />
            <p>Soma: {25 + 3}</p>
            <br />
            <p>{saudacao(userName)}</p>
            <p>{saudacao("José")}</p>

            {/* {Botão} */}
            <button onClick={ () => alert('Mensagem 📩')}>Clique aqui</button>

            {/* {Renderização Condicional} */}
            {userIslogged ? (
                // Caso estiver logado: true
                <div>
                    <p>Caso está logado</p>
                </div>
            ) : (
                // Caso nao estiver logado: false (else)
                    <div>
                        <p>Caso não está logado</p>
                    </div>
            )}
        </div>

    )
}

export default JsxExemplo
