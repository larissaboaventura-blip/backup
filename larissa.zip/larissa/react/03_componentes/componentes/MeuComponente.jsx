// Criar a função principal
function MeuComponente() {
    // Retorno do objeto jsx
    return (
        <div>
            <h3>Meu primeiro componente</h3>
        </div>
    )
}

// Exportar os dados do componente
export default MeuComponente