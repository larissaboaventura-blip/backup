import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import {createNativeStackNavigator, createNativeStackScreen } from '@react-navigation/native-stack';
import { Task } from './src/types';
import HomeScreen from './src/screens/HomeScreen';
import 

// Define a lista de telas
export type RootStackParamList = {
  Home: undefined;   // Chamada da tela existe, mas não precisa de parâmetro     
  Details: { task: Task };
};

// Cria a navegação entre as telas
const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" backgroundColor="#F7F8FA" />
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: #F7F8FA }
          }}>
          <Stack.Screen name='Home' component={HomeScreen} />
          <Stack.Screen name='Details' component={DetailsScreen} />
          </Stack.Navigator>
    </NavigationContainer>
  );
}
  

