import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context' 
import { NativeStackScreenProps } from '@react-navigation/native-stack'
import { RootStackParamList } from '../../App'

type Props = NativeStackScreenProps<RootStackParamList, 'Details'>

export default function DetailsScreen({ route, navigation }: Props) {
    const { task } = route.params

    return (
        <SafeAreaView>
            <View>
                <TouchableOpacity
                onPress={() => navigation.goBack()}
                hitSlop={12}
                >
                    <Text>Voltar</Text>
                </TouchableOpacity>
            </View>
            <Text style={StyleSheet.label}>Tarefa</Text>
            <Text style={StyleSheet.title}>{task.title}</Text>
            <View>
            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    safe: {
        flex: 1, 
        backgroundColor: '#F7F8A'
    },
    container: {
        flex: 1,
        paddingHorizontal: 20,
        paddingTop: 24
    },
    back: {
        fontSize: 16,
        color: '#111827',
        marginBottom: 24
    },
    card: {
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        padding: 20,
        shadowColor: '#000',
        shadowRadius: 8,
        shadowOffset: {width: 0, height: 2 },
        elevation: 2
    },
    label: {
        fontSize: 12,
        color: '#9CA3AF',
        textTransform: 'uppercase',
        marginTop: 16
    },
    title: {
        fontSize: 22,
        fontWeight: '700',
        color: '#111827',
        marginTop: 4
    }
})
