import './App.css'

function App() {

  return (
    </>
    <h1>Lista com Busca de API</h1>
    </>
  )
}

export default App
