import { useState } from "react"

function FormImc() {
  // Variáveis
  const [peso, setPeso] = useState('')
  const [altura, setAltura] = useState('')
  const [msg, setMsg] = useState(null)

  // Função Calcular IMC
  function calcularImc(e) {
    // Evitar recarregar a página
    e.preventDefault()

    // Tratar variáveis com casas decimais
    const pesoNum = parseFloat(peso)
    const alturaNum = parseFloat(altura)

    // Cálculo do IMC
    const resultado = pesoNum / (alturaNum * alturaNum)

    // Considerar 2 casas decimais
    const imc = resultado.toFixed(2)

    // Verificar situações do IMC
    if (resultado < 18.5) {
      setMsg(`IMC: ${imc} - Abaixo do Peso`)
    } else if (resultado < 25) {
      setMsg(`IMC: ${imc} - Peso Normal`)
    } else if (resultado < 30) {
      setMsg(`IMC: ${imc} - Sobrepeso`)
    } else {
      setMsg(`IMC: ${imc} - Obesidade`)
    }
  }
  return (
    <div>
      <form onSubmit={calcularImc}>
        <h2>Cálculo do IMC</h2>

        <div>
          <input
            type="text"
            name="peso"
            id="peso"
            plaaceholder="Informe o peso..."
            value={peso}
            onChange={(e) => setPeso(e.target.value)}
          />
        </div>

        <div>
          <input
            type="text"
            name="altura"
            id="altura"
            plaaceholder="Informe a altura..."
            value={altura}
            onChange={(e) => setAltura(e.target.value)}
          />
          0
        </div>

        <div>
          <input type="submit" value="Calcular" />
        </div>

        <div>
          <p>{msg}</p>
        </div>
      </form>
    </div>
  )
}

export default FormImc