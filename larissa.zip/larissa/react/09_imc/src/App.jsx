// import './App.css'
import FormImc from "./componentes/FormImc"

function App() {
  
  return (
    <>
      <FormImc/>
    </>
  )
}

export default App
